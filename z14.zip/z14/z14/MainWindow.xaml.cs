﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace z14
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public List <Person> PersLst = new List <Person>();
        public struct Person
        {
            public string name;
            public int age;
            public int ves;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            Person obj = new Person();
            //ListBox "возраст - " + obj.age+ "\nвес - "+ obj.ves+ "\nимя - "+ obj.name
            obj.name = TextBox1.Text;
            obj.age = Convert.ToInt32(TextBox2.Text);
            obj.ves = Convert.ToInt32(TextBox3.Text);
        }
    }
}
