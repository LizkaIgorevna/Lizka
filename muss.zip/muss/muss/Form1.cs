﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace muss
{
    public partial class Form1 : Form
    {
        //private static int i;
        public Form1()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        int[] mas = new int[10];

        private void button1_Click(object sender, EventArgs e)
        {
            string b = "";
            for (int i = 0; i < mas.Length; i++)
            {
                mas[i] = rnd.Next(-20,20);
                b += "[" + mas[i].ToString() + "]";
                label1.Text = mas.ToString();
            }
            label1.Text = b;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < Length; i++)
            {
                
            }
        }
    }
}
