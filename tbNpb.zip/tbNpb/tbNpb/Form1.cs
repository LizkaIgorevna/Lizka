﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tbNpb
{
    public partial class Form1 : Form
    {
        public int r, g, b;
        public int rab = 0;
        public int max_rab = 1000;
        public Form1()
        {
            InitializeComponent();
            r = 0;
            g = 0;
            b = 0;
            this.BackColor = Color.FromArgb(r, g, b);
            timer1.Interval = 10000; // 10000 миллисекунд
            timer1.Enabled = true;
            timer1.Tick += timer1_Tick;
        }


        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            r = trackBar1.Value;
            this.BackColor = Color.FromArgb(r, g, b);
            rab += trackBar1.Value;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            g = trackBar2.Value;
            this.BackColor = Color.FromArgb(r, g, b);
            rab += trackBar2.Value;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
            
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            b = trackBar3.Value;
            this.BackColor = Color.FromArgb(r, g, b);
            rab += trackBar3.Value;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.PerformStep();
            if (progressBar1.Value == progressBar1.Maximum)
            {
                timer1.Stop();
                MessageBox.Show("УПС.Закрывашкин");
                Application.Exit();
            }
        }
    }
}
