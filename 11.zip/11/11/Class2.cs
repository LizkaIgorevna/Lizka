﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11
{
    class Class2:Class1
    {
        public Class2(int a)
        {
            this.i += a;

        }
    }
}
