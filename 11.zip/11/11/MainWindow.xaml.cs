﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Class2 obj = new Class2(Convert.ToInt32(textbox1.Text));
            label1.Content = obj.mtd(obj.i).ToString();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Class4 obj = new Class4(Convert.ToInt32(textbox1.Text));
            label1.Content = obj.mtd(obj.i).ToString();
        }
    }
}
